rarityMap = {
	'Обычная': 'c',
	'Необычная' : 'u',
	'Редкая' : 'r',
	'Мифическая' : 'm',
}
execptions = {
	notexists : [
		{ set:'at', ids: [18, 80] },
		/* basic land with out arts */
		{ set: 'ddp', ids: [35,36,39,40,71,72] }
	],
	doubles: [
		{ set: 'chk', ids: [160] }
	],
	emptyset: [ 'etp', '4ea', 're', 'scgp']
}

function GetID(id, set) {
	for (var i = execptions.notexists.length - 1; i >= 0; i--) {
		var ne = execptions.notexists[i];
		if (ne.set == set) {
			for (var j = 0; j < ne.ids.length;j++) {
				if (id >= ne.ids[j])
					id++;
			};
		}
	};
	for (var i = execptions.doubles.length - 1; i >= 0; i--) {
		var dbl = execptions.doubles[i];
		if (dbl.set == set) {
			for (var j = 0; j < dbl.ids.length; j++) {
				if (id >= dbl.ids[j])
					id--;
			};
		}
	};
	return id;
};

function toDictionary(array) {
	var dict = {};
	for (var i = array.length - 1; i >= 0; i--) {
		dict[array[i].id] = array[i];
	};
	return dict;
}

chrome.storage.local.set({'setDiff': toDictionary($('.sub').map(
	function(i, item){ 
		return {	
			id: $('.titler .seticon', item).attr('class').substring(2,$('.titler .seticon', item).attr('class').indexOf(' ')), 
			//t: $('.titler .seticon', item).attr('title'), 
			c: toDictionary($('.ctclass',item).map(function(ii,card) { 
				return {
					id: GetID(ii + 1, $('.titler .seticon', item).attr('class').substring(2,$('.titler .seticon', item).attr('class').indexOf(' '))),
					//t: $('.tnamec',card).text(), 
					//tr:$('.smallfont',card).text(), 
					//foil:$('.foil',card).text(), 
					//condition: $('.sost',card).text(), 
					//r: rarityMap[$('.redkost',card).text()] || 's', 
					p: ($('.pprice',card).text().replace(/((\d+) ₽)?\s*((\d+) коп\.)?/, '$2.$4') + '0') * 1 || 0
	      		}; 
	        }).toArray())
	    }; 
	}).toArray())
});

